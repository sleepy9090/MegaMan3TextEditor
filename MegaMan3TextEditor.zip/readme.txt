Mega Man 3 NES ROM Text Editor v.1.0.0.35059 (including source)
Programmed by: Shawn M. Crawford [sleepy] 03/27/2016 in C#
---------------------------------------------------------

Features:
	* Edit text in the game 
	* Works with the USA ROM

Requires:
	* Targets .NET Framework 4.5

Usage:
	*Open the Rom, change text, click the Update Text button, make sure you have a backup in case something breaks.
	*This is first release so it will probably have bugs, feel free to email bugs to sleepy3d@gmail.com

TODO:
	* Optimize some routines for speed performance

Other:
        * If you use the source code for anything just tag me in your code, thanks!
        * Tested on Windows 8.1 Professional

1.0.0.35059  03/27/2016
---------------------------------------------------------
-initial release



