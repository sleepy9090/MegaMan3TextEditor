﻿namespace MegaMan3TextEditor {
    partial class Form9_rc {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form9_rc));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxRC33 = new System.Windows.Forms.TextBox();
            this.textBoxRC32 = new System.Windows.Forms.TextBox();
            this.textBoxRC31 = new System.Windows.Forms.TextBox();
            this.textBoxRC30 = new System.Windows.Forms.TextBox();
            this.textBoxRC29 = new System.Windows.Forms.TextBox();
            this.textBoxRC28 = new System.Windows.Forms.TextBox();
            this.textBoxRC27 = new System.Windows.Forms.TextBox();
            this.textBoxRC26 = new System.Windows.Forms.TextBox();
            this.textBoxRC25 = new System.Windows.Forms.TextBox();
            this.textBoxRC24 = new System.Windows.Forms.TextBox();
            this.textBoxRC23 = new System.Windows.Forms.TextBox();
            this.textBoxRC22 = new System.Windows.Forms.TextBox();
            this.textBoxRC21 = new System.Windows.Forms.TextBox();
            this.textBoxRC20 = new System.Windows.Forms.TextBox();
            this.textBoxRC19 = new System.Windows.Forms.TextBox();
            this.textBoxRC18 = new System.Windows.Forms.TextBox();
            this.textBoxRC17 = new System.Windows.Forms.TextBox();
            this.textBoxRC16 = new System.Windows.Forms.TextBox();
            this.textBoxRC15 = new System.Windows.Forms.TextBox();
            this.textBoxRC14 = new System.Windows.Forms.TextBox();
            this.textBoxRC13 = new System.Windows.Forms.TextBox();
            this.textBoxRC12 = new System.Windows.Forms.TextBox();
            this.textBoxRC11 = new System.Windows.Forms.TextBox();
            this.textBoxRC10 = new System.Windows.Forms.TextBox();
            this.textBoxRC9 = new System.Windows.Forms.TextBox();
            this.textBoxRC8 = new System.Windows.Forms.TextBox();
            this.textBoxRC7 = new System.Windows.Forms.TextBox();
            this.textBoxRC6 = new System.Windows.Forms.TextBox();
            this.textBoxRC5 = new System.Windows.Forms.TextBox();
            this.textBoxRC4 = new System.Windows.Forms.TextBox();
            this.textBoxRC3 = new System.Windows.Forms.TextBox();
            this.textBoxRC2 = new System.Windows.Forms.TextBox();
            this.textBoxRC1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxRC33);
            this.groupBox1.Controls.Add(this.textBoxRC32);
            this.groupBox1.Controls.Add(this.textBoxRC31);
            this.groupBox1.Controls.Add(this.textBoxRC30);
            this.groupBox1.Controls.Add(this.textBoxRC29);
            this.groupBox1.Controls.Add(this.textBoxRC28);
            this.groupBox1.Controls.Add(this.textBoxRC27);
            this.groupBox1.Controls.Add(this.textBoxRC26);
            this.groupBox1.Controls.Add(this.textBoxRC25);
            this.groupBox1.Controls.Add(this.textBoxRC24);
            this.groupBox1.Controls.Add(this.textBoxRC23);
            this.groupBox1.Controls.Add(this.textBoxRC22);
            this.groupBox1.Controls.Add(this.textBoxRC21);
            this.groupBox1.Controls.Add(this.textBoxRC20);
            this.groupBox1.Controls.Add(this.textBoxRC19);
            this.groupBox1.Controls.Add(this.textBoxRC18);
            this.groupBox1.Controls.Add(this.textBoxRC17);
            this.groupBox1.Controls.Add(this.textBoxRC16);
            this.groupBox1.Controls.Add(this.textBoxRC15);
            this.groupBox1.Controls.Add(this.textBoxRC14);
            this.groupBox1.Controls.Add(this.textBoxRC13);
            this.groupBox1.Controls.Add(this.textBoxRC12);
            this.groupBox1.Controls.Add(this.textBoxRC11);
            this.groupBox1.Controls.Add(this.textBoxRC10);
            this.groupBox1.Controls.Add(this.textBoxRC9);
            this.groupBox1.Controls.Add(this.textBoxRC8);
            this.groupBox1.Controls.Add(this.textBoxRC7);
            this.groupBox1.Controls.Add(this.textBoxRC6);
            this.groupBox1.Controls.Add(this.textBoxRC5);
            this.groupBox1.Controls.Add(this.textBoxRC4);
            this.groupBox1.Controls.Add(this.textBoxRC3);
            this.groupBox1.Controls.Add(this.textBoxRC2);
            this.groupBox1.Controls.Add(this.textBoxRC1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(432, 282);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "MM3 Robots/Creators";
            // 
            // textBoxRC33
            // 
            this.textBoxRC33.Location = new System.Drawing.Point(324, 71);
            this.textBoxRC33.Name = "textBoxRC33";
            this.textBoxRC33.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC33.TabIndex = 32;
            // 
            // textBoxRC32
            // 
            this.textBoxRC32.Location = new System.Drawing.Point(324, 45);
            this.textBoxRC32.Name = "textBoxRC32";
            this.textBoxRC32.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC32.TabIndex = 31;
            // 
            // textBoxRC31
            // 
            this.textBoxRC31.Location = new System.Drawing.Point(324, 19);
            this.textBoxRC31.Name = "textBoxRC31";
            this.textBoxRC31.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC31.TabIndex = 30;
            // 
            // textBoxRC30
            // 
            this.textBoxRC30.Location = new System.Drawing.Point(218, 253);
            this.textBoxRC30.Name = "textBoxRC30";
            this.textBoxRC30.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC30.TabIndex = 29;
            // 
            // textBoxRC29
            // 
            this.textBoxRC29.Location = new System.Drawing.Point(218, 227);
            this.textBoxRC29.Name = "textBoxRC29";
            this.textBoxRC29.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC29.TabIndex = 28;
            // 
            // textBoxRC28
            // 
            this.textBoxRC28.Location = new System.Drawing.Point(218, 201);
            this.textBoxRC28.Name = "textBoxRC28";
            this.textBoxRC28.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC28.TabIndex = 27;
            // 
            // textBoxRC27
            // 
            this.textBoxRC27.Location = new System.Drawing.Point(218, 175);
            this.textBoxRC27.Name = "textBoxRC27";
            this.textBoxRC27.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC27.TabIndex = 26;
            // 
            // textBoxRC26
            // 
            this.textBoxRC26.Location = new System.Drawing.Point(218, 149);
            this.textBoxRC26.Name = "textBoxRC26";
            this.textBoxRC26.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC26.TabIndex = 25;
            // 
            // textBoxRC25
            // 
            this.textBoxRC25.Location = new System.Drawing.Point(218, 123);
            this.textBoxRC25.Name = "textBoxRC25";
            this.textBoxRC25.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC25.TabIndex = 24;
            // 
            // textBoxRC24
            // 
            this.textBoxRC24.Location = new System.Drawing.Point(218, 97);
            this.textBoxRC24.Name = "textBoxRC24";
            this.textBoxRC24.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC24.TabIndex = 23;
            // 
            // textBoxRC23
            // 
            this.textBoxRC23.Location = new System.Drawing.Point(218, 71);
            this.textBoxRC23.Name = "textBoxRC23";
            this.textBoxRC23.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC23.TabIndex = 22;
            // 
            // textBoxRC22
            // 
            this.textBoxRC22.Location = new System.Drawing.Point(218, 45);
            this.textBoxRC22.Name = "textBoxRC22";
            this.textBoxRC22.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC22.TabIndex = 21;
            // 
            // textBoxRC21
            // 
            this.textBoxRC21.Location = new System.Drawing.Point(218, 19);
            this.textBoxRC21.Name = "textBoxRC21";
            this.textBoxRC21.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC21.TabIndex = 20;
            // 
            // textBoxRC20
            // 
            this.textBoxRC20.Location = new System.Drawing.Point(112, 253);
            this.textBoxRC20.Name = "textBoxRC20";
            this.textBoxRC20.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC20.TabIndex = 19;
            // 
            // textBoxRC19
            // 
            this.textBoxRC19.Location = new System.Drawing.Point(112, 227);
            this.textBoxRC19.Name = "textBoxRC19";
            this.textBoxRC19.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC19.TabIndex = 18;
            // 
            // textBoxRC18
            // 
            this.textBoxRC18.Location = new System.Drawing.Point(112, 201);
            this.textBoxRC18.Name = "textBoxRC18";
            this.textBoxRC18.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC18.TabIndex = 17;
            // 
            // textBoxRC17
            // 
            this.textBoxRC17.Location = new System.Drawing.Point(112, 175);
            this.textBoxRC17.Name = "textBoxRC17";
            this.textBoxRC17.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC17.TabIndex = 16;
            // 
            // textBoxRC16
            // 
            this.textBoxRC16.Location = new System.Drawing.Point(112, 149);
            this.textBoxRC16.Name = "textBoxRC16";
            this.textBoxRC16.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC16.TabIndex = 15;
            // 
            // textBoxRC15
            // 
            this.textBoxRC15.Location = new System.Drawing.Point(112, 123);
            this.textBoxRC15.Name = "textBoxRC15";
            this.textBoxRC15.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC15.TabIndex = 14;
            // 
            // textBoxRC14
            // 
            this.textBoxRC14.Location = new System.Drawing.Point(112, 97);
            this.textBoxRC14.Name = "textBoxRC14";
            this.textBoxRC14.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC14.TabIndex = 13;
            // 
            // textBoxRC13
            // 
            this.textBoxRC13.Location = new System.Drawing.Point(112, 71);
            this.textBoxRC13.Name = "textBoxRC13";
            this.textBoxRC13.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC13.TabIndex = 12;
            // 
            // textBoxRC12
            // 
            this.textBoxRC12.Location = new System.Drawing.Point(112, 45);
            this.textBoxRC12.Name = "textBoxRC12";
            this.textBoxRC12.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC12.TabIndex = 11;
            // 
            // textBoxRC11
            // 
            this.textBoxRC11.Location = new System.Drawing.Point(112, 19);
            this.textBoxRC11.Name = "textBoxRC11";
            this.textBoxRC11.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC11.TabIndex = 10;
            // 
            // textBoxRC10
            // 
            this.textBoxRC10.Location = new System.Drawing.Point(6, 253);
            this.textBoxRC10.Name = "textBoxRC10";
            this.textBoxRC10.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC10.TabIndex = 9;
            // 
            // textBoxRC9
            // 
            this.textBoxRC9.Location = new System.Drawing.Point(6, 227);
            this.textBoxRC9.Name = "textBoxRC9";
            this.textBoxRC9.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC9.TabIndex = 8;
            // 
            // textBoxRC8
            // 
            this.textBoxRC8.Location = new System.Drawing.Point(6, 201);
            this.textBoxRC8.Name = "textBoxRC8";
            this.textBoxRC8.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC8.TabIndex = 7;
            // 
            // textBoxRC7
            // 
            this.textBoxRC7.Location = new System.Drawing.Point(6, 175);
            this.textBoxRC7.Name = "textBoxRC7";
            this.textBoxRC7.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC7.TabIndex = 6;
            // 
            // textBoxRC6
            // 
            this.textBoxRC6.Location = new System.Drawing.Point(6, 149);
            this.textBoxRC6.Name = "textBoxRC6";
            this.textBoxRC6.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC6.TabIndex = 5;
            // 
            // textBoxRC5
            // 
            this.textBoxRC5.Location = new System.Drawing.Point(6, 123);
            this.textBoxRC5.Name = "textBoxRC5";
            this.textBoxRC5.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC5.TabIndex = 4;
            // 
            // textBoxRC4
            // 
            this.textBoxRC4.Location = new System.Drawing.Point(6, 97);
            this.textBoxRC4.Name = "textBoxRC4";
            this.textBoxRC4.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC4.TabIndex = 3;
            // 
            // textBoxRC3
            // 
            this.textBoxRC3.Location = new System.Drawing.Point(6, 71);
            this.textBoxRC3.Name = "textBoxRC3";
            this.textBoxRC3.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC3.TabIndex = 2;
            // 
            // textBoxRC2
            // 
            this.textBoxRC2.Location = new System.Drawing.Point(6, 45);
            this.textBoxRC2.Name = "textBoxRC2";
            this.textBoxRC2.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC2.TabIndex = 1;
            // 
            // textBoxRC1
            // 
            this.textBoxRC1.Location = new System.Drawing.Point(6, 19);
            this.textBoxRC1.Name = "textBoxRC1";
            this.textBoxRC1.Size = new System.Drawing.Size(100, 20);
            this.textBoxRC1.TabIndex = 0;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(361, 300);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 1;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // Form9_rc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 330);
            this.Controls.Add(this.buttonUpdateText);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form9_rc";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form9_rc_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonUpdateText;
        private System.Windows.Forms.TextBox textBoxRC1;
        private System.Windows.Forms.TextBox textBoxRC32;
        private System.Windows.Forms.TextBox textBoxRC31;
        private System.Windows.Forms.TextBox textBoxRC30;
        private System.Windows.Forms.TextBox textBoxRC29;
        private System.Windows.Forms.TextBox textBoxRC28;
        private System.Windows.Forms.TextBox textBoxRC27;
        private System.Windows.Forms.TextBox textBoxRC26;
        private System.Windows.Forms.TextBox textBoxRC25;
        private System.Windows.Forms.TextBox textBoxRC24;
        private System.Windows.Forms.TextBox textBoxRC23;
        private System.Windows.Forms.TextBox textBoxRC22;
        private System.Windows.Forms.TextBox textBoxRC21;
        private System.Windows.Forms.TextBox textBoxRC20;
        private System.Windows.Forms.TextBox textBoxRC19;
        private System.Windows.Forms.TextBox textBoxRC18;
        private System.Windows.Forms.TextBox textBoxRC17;
        private System.Windows.Forms.TextBox textBoxRC16;
        private System.Windows.Forms.TextBox textBoxRC15;
        private System.Windows.Forms.TextBox textBoxRC14;
        private System.Windows.Forms.TextBox textBoxRC13;
        private System.Windows.Forms.TextBox textBoxRC12;
        private System.Windows.Forms.TextBox textBoxRC11;
        private System.Windows.Forms.TextBox textBoxRC10;
        private System.Windows.Forms.TextBox textBoxRC9;
        private System.Windows.Forms.TextBox textBoxRC8;
        private System.Windows.Forms.TextBox textBoxRC7;
        private System.Windows.Forms.TextBox textBoxRC6;
        private System.Windows.Forms.TextBox textBoxRC5;
        private System.Windows.Forms.TextBox textBoxRC4;
        private System.Windows.Forms.TextBox textBoxRC3;
        private System.Windows.Forms.TextBox textBoxRC2;
        private System.Windows.Forms.TextBox textBoxRC33;
    }
}