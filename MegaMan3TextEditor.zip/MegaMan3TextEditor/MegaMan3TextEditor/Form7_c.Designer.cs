﻿namespace MegaMan3TextEditor {
    partial class Form7_c {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7_c));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxC59 = new System.Windows.Forms.TextBox();
            this.textBoxC48 = new System.Windows.Forms.TextBox();
            this.textBoxC47 = new System.Windows.Forms.TextBox();
            this.textBoxC36 = new System.Windows.Forms.TextBox();
            this.textBoxC35 = new System.Windows.Forms.TextBox();
            this.textBoxC24 = new System.Windows.Forms.TextBox();
            this.textBoxC23 = new System.Windows.Forms.TextBox();
            this.textBoxC12 = new System.Windows.Forms.TextBox();
            this.textBoxC11 = new System.Windows.Forms.TextBox();
            this.textBoxC58 = new System.Windows.Forms.TextBox();
            this.textBoxC57 = new System.Windows.Forms.TextBox();
            this.textBoxC56 = new System.Windows.Forms.TextBox();
            this.textBoxC55 = new System.Windows.Forms.TextBox();
            this.textBoxC54 = new System.Windows.Forms.TextBox();
            this.textBoxC53 = new System.Windows.Forms.TextBox();
            this.textBoxC52 = new System.Windows.Forms.TextBox();
            this.textBoxC51 = new System.Windows.Forms.TextBox();
            this.textBoxC50 = new System.Windows.Forms.TextBox();
            this.textBoxC49 = new System.Windows.Forms.TextBox();
            this.textBoxC46 = new System.Windows.Forms.TextBox();
            this.textBoxC45 = new System.Windows.Forms.TextBox();
            this.textBoxC44 = new System.Windows.Forms.TextBox();
            this.textBoxC43 = new System.Windows.Forms.TextBox();
            this.textBoxC42 = new System.Windows.Forms.TextBox();
            this.textBoxC41 = new System.Windows.Forms.TextBox();
            this.textBoxC40 = new System.Windows.Forms.TextBox();
            this.textBoxC39 = new System.Windows.Forms.TextBox();
            this.textBoxC38 = new System.Windows.Forms.TextBox();
            this.textBoxC37 = new System.Windows.Forms.TextBox();
            this.textBoxC34 = new System.Windows.Forms.TextBox();
            this.textBoxC33 = new System.Windows.Forms.TextBox();
            this.textBoxC32 = new System.Windows.Forms.TextBox();
            this.textBoxC31 = new System.Windows.Forms.TextBox();
            this.textBoxC30 = new System.Windows.Forms.TextBox();
            this.textBoxC29 = new System.Windows.Forms.TextBox();
            this.textBoxC28 = new System.Windows.Forms.TextBox();
            this.textBoxC27 = new System.Windows.Forms.TextBox();
            this.textBoxC26 = new System.Windows.Forms.TextBox();
            this.textBoxC25 = new System.Windows.Forms.TextBox();
            this.textBoxC22 = new System.Windows.Forms.TextBox();
            this.textBoxC21 = new System.Windows.Forms.TextBox();
            this.textBoxC20 = new System.Windows.Forms.TextBox();
            this.textBoxC19 = new System.Windows.Forms.TextBox();
            this.textBoxC18 = new System.Windows.Forms.TextBox();
            this.textBoxC17 = new System.Windows.Forms.TextBox();
            this.textBoxC16 = new System.Windows.Forms.TextBox();
            this.textBoxC15 = new System.Windows.Forms.TextBox();
            this.textBoxC14 = new System.Windows.Forms.TextBox();
            this.textBoxC13 = new System.Windows.Forms.TextBox();
            this.textBoxC10 = new System.Windows.Forms.TextBox();
            this.textBoxC9 = new System.Windows.Forms.TextBox();
            this.textBoxC8 = new System.Windows.Forms.TextBox();
            this.textBoxC7 = new System.Windows.Forms.TextBox();
            this.textBoxC6 = new System.Windows.Forms.TextBox();
            this.textBoxC5 = new System.Windows.Forms.TextBox();
            this.textBoxC4 = new System.Windows.Forms.TextBox();
            this.textBoxC3 = new System.Windows.Forms.TextBox();
            this.textBoxC2 = new System.Windows.Forms.TextBox();
            this.textBoxC1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxC59);
            this.groupBox1.Controls.Add(this.textBoxC48);
            this.groupBox1.Controls.Add(this.textBoxC47);
            this.groupBox1.Controls.Add(this.textBoxC36);
            this.groupBox1.Controls.Add(this.textBoxC35);
            this.groupBox1.Controls.Add(this.textBoxC24);
            this.groupBox1.Controls.Add(this.textBoxC23);
            this.groupBox1.Controls.Add(this.textBoxC12);
            this.groupBox1.Controls.Add(this.textBoxC11);
            this.groupBox1.Controls.Add(this.textBoxC58);
            this.groupBox1.Controls.Add(this.textBoxC57);
            this.groupBox1.Controls.Add(this.textBoxC56);
            this.groupBox1.Controls.Add(this.textBoxC55);
            this.groupBox1.Controls.Add(this.textBoxC54);
            this.groupBox1.Controls.Add(this.textBoxC53);
            this.groupBox1.Controls.Add(this.textBoxC52);
            this.groupBox1.Controls.Add(this.textBoxC51);
            this.groupBox1.Controls.Add(this.textBoxC50);
            this.groupBox1.Controls.Add(this.textBoxC49);
            this.groupBox1.Controls.Add(this.textBoxC46);
            this.groupBox1.Controls.Add(this.textBoxC45);
            this.groupBox1.Controls.Add(this.textBoxC44);
            this.groupBox1.Controls.Add(this.textBoxC43);
            this.groupBox1.Controls.Add(this.textBoxC42);
            this.groupBox1.Controls.Add(this.textBoxC41);
            this.groupBox1.Controls.Add(this.textBoxC40);
            this.groupBox1.Controls.Add(this.textBoxC39);
            this.groupBox1.Controls.Add(this.textBoxC38);
            this.groupBox1.Controls.Add(this.textBoxC37);
            this.groupBox1.Controls.Add(this.textBoxC34);
            this.groupBox1.Controls.Add(this.textBoxC33);
            this.groupBox1.Controls.Add(this.textBoxC32);
            this.groupBox1.Controls.Add(this.textBoxC31);
            this.groupBox1.Controls.Add(this.textBoxC30);
            this.groupBox1.Controls.Add(this.textBoxC29);
            this.groupBox1.Controls.Add(this.textBoxC28);
            this.groupBox1.Controls.Add(this.textBoxC27);
            this.groupBox1.Controls.Add(this.textBoxC26);
            this.groupBox1.Controls.Add(this.textBoxC25);
            this.groupBox1.Controls.Add(this.textBoxC22);
            this.groupBox1.Controls.Add(this.textBoxC21);
            this.groupBox1.Controls.Add(this.textBoxC20);
            this.groupBox1.Controls.Add(this.textBoxC19);
            this.groupBox1.Controls.Add(this.textBoxC18);
            this.groupBox1.Controls.Add(this.textBoxC17);
            this.groupBox1.Controls.Add(this.textBoxC16);
            this.groupBox1.Controls.Add(this.textBoxC15);
            this.groupBox1.Controls.Add(this.textBoxC14);
            this.groupBox1.Controls.Add(this.textBoxC13);
            this.groupBox1.Controls.Add(this.textBoxC10);
            this.groupBox1.Controls.Add(this.textBoxC9);
            this.groupBox1.Controls.Add(this.textBoxC8);
            this.groupBox1.Controls.Add(this.textBoxC7);
            this.groupBox1.Controls.Add(this.textBoxC6);
            this.groupBox1.Controls.Add(this.textBoxC5);
            this.groupBox1.Controls.Add(this.textBoxC4);
            this.groupBox1.Controls.Add(this.textBoxC3);
            this.groupBox1.Controls.Add(this.textBoxC2);
            this.groupBox1.Controls.Add(this.textBoxC1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(540, 335);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Credits";
            // 
            // textBoxC59
            // 
            this.textBoxC59.Location = new System.Drawing.Point(430, 279);
            this.textBoxC59.Name = "textBoxC59";
            this.textBoxC59.Size = new System.Drawing.Size(100, 20);
            this.textBoxC59.TabIndex = 54;
            // 
            // textBoxC48
            // 
            this.textBoxC48.Location = new System.Drawing.Point(324, 305);
            this.textBoxC48.Name = "textBoxC48";
            this.textBoxC48.Size = new System.Drawing.Size(100, 20);
            this.textBoxC48.TabIndex = 58;
            // 
            // textBoxC47
            // 
            this.textBoxC47.Location = new System.Drawing.Point(324, 279);
            this.textBoxC47.Name = "textBoxC47";
            this.textBoxC47.Size = new System.Drawing.Size(100, 20);
            this.textBoxC47.TabIndex = 53;
            // 
            // textBoxC36
            // 
            this.textBoxC36.Location = new System.Drawing.Point(218, 305);
            this.textBoxC36.Name = "textBoxC36";
            this.textBoxC36.Size = new System.Drawing.Size(100, 20);
            this.textBoxC36.TabIndex = 57;
            // 
            // textBoxC35
            // 
            this.textBoxC35.Location = new System.Drawing.Point(218, 279);
            this.textBoxC35.Name = "textBoxC35";
            this.textBoxC35.Size = new System.Drawing.Size(100, 20);
            this.textBoxC35.TabIndex = 52;
            // 
            // textBoxC24
            // 
            this.textBoxC24.Location = new System.Drawing.Point(112, 305);
            this.textBoxC24.Name = "textBoxC24";
            this.textBoxC24.Size = new System.Drawing.Size(100, 20);
            this.textBoxC24.TabIndex = 56;
            // 
            // textBoxC23
            // 
            this.textBoxC23.Location = new System.Drawing.Point(112, 279);
            this.textBoxC23.Name = "textBoxC23";
            this.textBoxC23.Size = new System.Drawing.Size(100, 20);
            this.textBoxC23.TabIndex = 51;
            // 
            // textBoxC12
            // 
            this.textBoxC12.Location = new System.Drawing.Point(6, 305);
            this.textBoxC12.Name = "textBoxC12";
            this.textBoxC12.Size = new System.Drawing.Size(100, 20);
            this.textBoxC12.TabIndex = 55;
            // 
            // textBoxC11
            // 
            this.textBoxC11.Location = new System.Drawing.Point(6, 279);
            this.textBoxC11.Name = "textBoxC11";
            this.textBoxC11.Size = new System.Drawing.Size(100, 20);
            this.textBoxC11.TabIndex = 50;
            // 
            // textBoxC58
            // 
            this.textBoxC58.Location = new System.Drawing.Point(430, 253);
            this.textBoxC58.Name = "textBoxC58";
            this.textBoxC58.Size = new System.Drawing.Size(100, 20);
            this.textBoxC58.TabIndex = 49;
            // 
            // textBoxC57
            // 
            this.textBoxC57.Location = new System.Drawing.Point(430, 227);
            this.textBoxC57.Name = "textBoxC57";
            this.textBoxC57.Size = new System.Drawing.Size(100, 20);
            this.textBoxC57.TabIndex = 44;
            // 
            // textBoxC56
            // 
            this.textBoxC56.Location = new System.Drawing.Point(430, 201);
            this.textBoxC56.Name = "textBoxC56";
            this.textBoxC56.Size = new System.Drawing.Size(100, 20);
            this.textBoxC56.TabIndex = 39;
            // 
            // textBoxC55
            // 
            this.textBoxC55.Location = new System.Drawing.Point(430, 175);
            this.textBoxC55.Name = "textBoxC55";
            this.textBoxC55.Size = new System.Drawing.Size(100, 20);
            this.textBoxC55.TabIndex = 34;
            // 
            // textBoxC54
            // 
            this.textBoxC54.Location = new System.Drawing.Point(430, 149);
            this.textBoxC54.Name = "textBoxC54";
            this.textBoxC54.Size = new System.Drawing.Size(100, 20);
            this.textBoxC54.TabIndex = 29;
            // 
            // textBoxC53
            // 
            this.textBoxC53.Location = new System.Drawing.Point(430, 123);
            this.textBoxC53.Name = "textBoxC53";
            this.textBoxC53.Size = new System.Drawing.Size(100, 20);
            this.textBoxC53.TabIndex = 24;
            // 
            // textBoxC52
            // 
            this.textBoxC52.Location = new System.Drawing.Point(430, 97);
            this.textBoxC52.Name = "textBoxC52";
            this.textBoxC52.Size = new System.Drawing.Size(100, 20);
            this.textBoxC52.TabIndex = 19;
            // 
            // textBoxC51
            // 
            this.textBoxC51.Location = new System.Drawing.Point(430, 71);
            this.textBoxC51.Name = "textBoxC51";
            this.textBoxC51.Size = new System.Drawing.Size(100, 20);
            this.textBoxC51.TabIndex = 14;
            // 
            // textBoxC50
            // 
            this.textBoxC50.Location = new System.Drawing.Point(430, 45);
            this.textBoxC50.Name = "textBoxC50";
            this.textBoxC50.Size = new System.Drawing.Size(100, 20);
            this.textBoxC50.TabIndex = 9;
            // 
            // textBoxC49
            // 
            this.textBoxC49.Location = new System.Drawing.Point(430, 19);
            this.textBoxC49.Name = "textBoxC49";
            this.textBoxC49.Size = new System.Drawing.Size(100, 20);
            this.textBoxC49.TabIndex = 4;
            // 
            // textBoxC46
            // 
            this.textBoxC46.Location = new System.Drawing.Point(324, 253);
            this.textBoxC46.Name = "textBoxC46";
            this.textBoxC46.Size = new System.Drawing.Size(100, 20);
            this.textBoxC46.TabIndex = 48;
            // 
            // textBoxC45
            // 
            this.textBoxC45.Location = new System.Drawing.Point(324, 227);
            this.textBoxC45.Name = "textBoxC45";
            this.textBoxC45.Size = new System.Drawing.Size(100, 20);
            this.textBoxC45.TabIndex = 43;
            // 
            // textBoxC44
            // 
            this.textBoxC44.Location = new System.Drawing.Point(324, 201);
            this.textBoxC44.Name = "textBoxC44";
            this.textBoxC44.Size = new System.Drawing.Size(100, 20);
            this.textBoxC44.TabIndex = 38;
            // 
            // textBoxC43
            // 
            this.textBoxC43.Location = new System.Drawing.Point(324, 175);
            this.textBoxC43.Name = "textBoxC43";
            this.textBoxC43.Size = new System.Drawing.Size(100, 20);
            this.textBoxC43.TabIndex = 33;
            // 
            // textBoxC42
            // 
            this.textBoxC42.Location = new System.Drawing.Point(324, 149);
            this.textBoxC42.Name = "textBoxC42";
            this.textBoxC42.Size = new System.Drawing.Size(100, 20);
            this.textBoxC42.TabIndex = 28;
            // 
            // textBoxC41
            // 
            this.textBoxC41.Location = new System.Drawing.Point(324, 123);
            this.textBoxC41.Name = "textBoxC41";
            this.textBoxC41.Size = new System.Drawing.Size(100, 20);
            this.textBoxC41.TabIndex = 23;
            // 
            // textBoxC40
            // 
            this.textBoxC40.Location = new System.Drawing.Point(324, 97);
            this.textBoxC40.Name = "textBoxC40";
            this.textBoxC40.Size = new System.Drawing.Size(100, 20);
            this.textBoxC40.TabIndex = 18;
            // 
            // textBoxC39
            // 
            this.textBoxC39.Location = new System.Drawing.Point(324, 71);
            this.textBoxC39.Name = "textBoxC39";
            this.textBoxC39.Size = new System.Drawing.Size(100, 20);
            this.textBoxC39.TabIndex = 13;
            // 
            // textBoxC38
            // 
            this.textBoxC38.Location = new System.Drawing.Point(324, 45);
            this.textBoxC38.Name = "textBoxC38";
            this.textBoxC38.Size = new System.Drawing.Size(100, 20);
            this.textBoxC38.TabIndex = 8;
            // 
            // textBoxC37
            // 
            this.textBoxC37.Location = new System.Drawing.Point(324, 19);
            this.textBoxC37.Name = "textBoxC37";
            this.textBoxC37.Size = new System.Drawing.Size(100, 20);
            this.textBoxC37.TabIndex = 3;
            // 
            // textBoxC34
            // 
            this.textBoxC34.Location = new System.Drawing.Point(218, 253);
            this.textBoxC34.Name = "textBoxC34";
            this.textBoxC34.Size = new System.Drawing.Size(100, 20);
            this.textBoxC34.TabIndex = 47;
            // 
            // textBoxC33
            // 
            this.textBoxC33.Location = new System.Drawing.Point(218, 227);
            this.textBoxC33.Name = "textBoxC33";
            this.textBoxC33.Size = new System.Drawing.Size(100, 20);
            this.textBoxC33.TabIndex = 42;
            // 
            // textBoxC32
            // 
            this.textBoxC32.Location = new System.Drawing.Point(218, 201);
            this.textBoxC32.Name = "textBoxC32";
            this.textBoxC32.Size = new System.Drawing.Size(100, 20);
            this.textBoxC32.TabIndex = 37;
            // 
            // textBoxC31
            // 
            this.textBoxC31.Location = new System.Drawing.Point(218, 175);
            this.textBoxC31.Name = "textBoxC31";
            this.textBoxC31.Size = new System.Drawing.Size(100, 20);
            this.textBoxC31.TabIndex = 32;
            // 
            // textBoxC30
            // 
            this.textBoxC30.Location = new System.Drawing.Point(218, 149);
            this.textBoxC30.Name = "textBoxC30";
            this.textBoxC30.Size = new System.Drawing.Size(100, 20);
            this.textBoxC30.TabIndex = 27;
            // 
            // textBoxC29
            // 
            this.textBoxC29.Location = new System.Drawing.Point(218, 123);
            this.textBoxC29.Name = "textBoxC29";
            this.textBoxC29.Size = new System.Drawing.Size(100, 20);
            this.textBoxC29.TabIndex = 22;
            // 
            // textBoxC28
            // 
            this.textBoxC28.Location = new System.Drawing.Point(218, 97);
            this.textBoxC28.Name = "textBoxC28";
            this.textBoxC28.Size = new System.Drawing.Size(100, 20);
            this.textBoxC28.TabIndex = 17;
            // 
            // textBoxC27
            // 
            this.textBoxC27.Location = new System.Drawing.Point(218, 71);
            this.textBoxC27.Name = "textBoxC27";
            this.textBoxC27.Size = new System.Drawing.Size(100, 20);
            this.textBoxC27.TabIndex = 12;
            // 
            // textBoxC26
            // 
            this.textBoxC26.Location = new System.Drawing.Point(218, 45);
            this.textBoxC26.Name = "textBoxC26";
            this.textBoxC26.Size = new System.Drawing.Size(100, 20);
            this.textBoxC26.TabIndex = 7;
            // 
            // textBoxC25
            // 
            this.textBoxC25.Location = new System.Drawing.Point(218, 19);
            this.textBoxC25.Name = "textBoxC25";
            this.textBoxC25.Size = new System.Drawing.Size(100, 20);
            this.textBoxC25.TabIndex = 2;
            // 
            // textBoxC22
            // 
            this.textBoxC22.Location = new System.Drawing.Point(112, 253);
            this.textBoxC22.Name = "textBoxC22";
            this.textBoxC22.Size = new System.Drawing.Size(100, 20);
            this.textBoxC22.TabIndex = 46;
            // 
            // textBoxC21
            // 
            this.textBoxC21.Location = new System.Drawing.Point(112, 227);
            this.textBoxC21.Name = "textBoxC21";
            this.textBoxC21.Size = new System.Drawing.Size(100, 20);
            this.textBoxC21.TabIndex = 41;
            // 
            // textBoxC20
            // 
            this.textBoxC20.Location = new System.Drawing.Point(112, 201);
            this.textBoxC20.Name = "textBoxC20";
            this.textBoxC20.Size = new System.Drawing.Size(100, 20);
            this.textBoxC20.TabIndex = 36;
            // 
            // textBoxC19
            // 
            this.textBoxC19.Location = new System.Drawing.Point(112, 175);
            this.textBoxC19.Name = "textBoxC19";
            this.textBoxC19.Size = new System.Drawing.Size(100, 20);
            this.textBoxC19.TabIndex = 31;
            // 
            // textBoxC18
            // 
            this.textBoxC18.Location = new System.Drawing.Point(112, 149);
            this.textBoxC18.Name = "textBoxC18";
            this.textBoxC18.Size = new System.Drawing.Size(100, 20);
            this.textBoxC18.TabIndex = 26;
            // 
            // textBoxC17
            // 
            this.textBoxC17.Location = new System.Drawing.Point(112, 123);
            this.textBoxC17.Name = "textBoxC17";
            this.textBoxC17.Size = new System.Drawing.Size(100, 20);
            this.textBoxC17.TabIndex = 21;
            // 
            // textBoxC16
            // 
            this.textBoxC16.Location = new System.Drawing.Point(112, 97);
            this.textBoxC16.Name = "textBoxC16";
            this.textBoxC16.Size = new System.Drawing.Size(100, 20);
            this.textBoxC16.TabIndex = 16;
            // 
            // textBoxC15
            // 
            this.textBoxC15.Location = new System.Drawing.Point(112, 71);
            this.textBoxC15.Name = "textBoxC15";
            this.textBoxC15.Size = new System.Drawing.Size(100, 20);
            this.textBoxC15.TabIndex = 11;
            // 
            // textBoxC14
            // 
            this.textBoxC14.Location = new System.Drawing.Point(112, 45);
            this.textBoxC14.Name = "textBoxC14";
            this.textBoxC14.Size = new System.Drawing.Size(100, 20);
            this.textBoxC14.TabIndex = 6;
            // 
            // textBoxC13
            // 
            this.textBoxC13.Location = new System.Drawing.Point(112, 19);
            this.textBoxC13.Name = "textBoxC13";
            this.textBoxC13.Size = new System.Drawing.Size(100, 20);
            this.textBoxC13.TabIndex = 1;
            // 
            // textBoxC10
            // 
            this.textBoxC10.Location = new System.Drawing.Point(6, 253);
            this.textBoxC10.Name = "textBoxC10";
            this.textBoxC10.Size = new System.Drawing.Size(100, 20);
            this.textBoxC10.TabIndex = 45;
            // 
            // textBoxC9
            // 
            this.textBoxC9.Location = new System.Drawing.Point(6, 227);
            this.textBoxC9.Name = "textBoxC9";
            this.textBoxC9.Size = new System.Drawing.Size(100, 20);
            this.textBoxC9.TabIndex = 40;
            // 
            // textBoxC8
            // 
            this.textBoxC8.Location = new System.Drawing.Point(6, 201);
            this.textBoxC8.Name = "textBoxC8";
            this.textBoxC8.Size = new System.Drawing.Size(100, 20);
            this.textBoxC8.TabIndex = 35;
            // 
            // textBoxC7
            // 
            this.textBoxC7.Location = new System.Drawing.Point(6, 175);
            this.textBoxC7.Name = "textBoxC7";
            this.textBoxC7.Size = new System.Drawing.Size(100, 20);
            this.textBoxC7.TabIndex = 30;
            // 
            // textBoxC6
            // 
            this.textBoxC6.Location = new System.Drawing.Point(6, 149);
            this.textBoxC6.Name = "textBoxC6";
            this.textBoxC6.Size = new System.Drawing.Size(100, 20);
            this.textBoxC6.TabIndex = 25;
            // 
            // textBoxC5
            // 
            this.textBoxC5.Location = new System.Drawing.Point(6, 123);
            this.textBoxC5.Name = "textBoxC5";
            this.textBoxC5.Size = new System.Drawing.Size(100, 20);
            this.textBoxC5.TabIndex = 20;
            // 
            // textBoxC4
            // 
            this.textBoxC4.Location = new System.Drawing.Point(6, 97);
            this.textBoxC4.Name = "textBoxC4";
            this.textBoxC4.Size = new System.Drawing.Size(100, 20);
            this.textBoxC4.TabIndex = 15;
            // 
            // textBoxC3
            // 
            this.textBoxC3.Location = new System.Drawing.Point(6, 71);
            this.textBoxC3.Name = "textBoxC3";
            this.textBoxC3.Size = new System.Drawing.Size(100, 20);
            this.textBoxC3.TabIndex = 10;
            // 
            // textBoxC2
            // 
            this.textBoxC2.Location = new System.Drawing.Point(6, 45);
            this.textBoxC2.Name = "textBoxC2";
            this.textBoxC2.Size = new System.Drawing.Size(100, 20);
            this.textBoxC2.TabIndex = 5;
            // 
            // textBoxC1
            // 
            this.textBoxC1.Location = new System.Drawing.Point(6, 19);
            this.textBoxC1.Name = "textBoxC1";
            this.textBoxC1.Size = new System.Drawing.Size(100, 20);
            this.textBoxC1.TabIndex = 0;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(467, 353);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 1;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // Form7_c
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 383);
            this.Controls.Add(this.buttonUpdateText);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form7_c";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form7_c_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonUpdateText;
        private System.Windows.Forms.TextBox textBoxC1;
        private System.Windows.Forms.TextBox textBoxC10;
        private System.Windows.Forms.TextBox textBoxC9;
        private System.Windows.Forms.TextBox textBoxC8;
        private System.Windows.Forms.TextBox textBoxC7;
        private System.Windows.Forms.TextBox textBoxC6;
        private System.Windows.Forms.TextBox textBoxC5;
        private System.Windows.Forms.TextBox textBoxC4;
        private System.Windows.Forms.TextBox textBoxC3;
        private System.Windows.Forms.TextBox textBoxC2;
        private System.Windows.Forms.TextBox textBoxC59;
        private System.Windows.Forms.TextBox textBoxC48;
        private System.Windows.Forms.TextBox textBoxC47;
        private System.Windows.Forms.TextBox textBoxC36;
        private System.Windows.Forms.TextBox textBoxC35;
        private System.Windows.Forms.TextBox textBoxC24;
        private System.Windows.Forms.TextBox textBoxC23;
        private System.Windows.Forms.TextBox textBoxC12;
        private System.Windows.Forms.TextBox textBoxC11;
        private System.Windows.Forms.TextBox textBoxC58;
        private System.Windows.Forms.TextBox textBoxC57;
        private System.Windows.Forms.TextBox textBoxC56;
        private System.Windows.Forms.TextBox textBoxC55;
        private System.Windows.Forms.TextBox textBoxC54;
        private System.Windows.Forms.TextBox textBoxC53;
        private System.Windows.Forms.TextBox textBoxC52;
        private System.Windows.Forms.TextBox textBoxC51;
        private System.Windows.Forms.TextBox textBoxC50;
        private System.Windows.Forms.TextBox textBoxC49;
        private System.Windows.Forms.TextBox textBoxC46;
        private System.Windows.Forms.TextBox textBoxC45;
        private System.Windows.Forms.TextBox textBoxC44;
        private System.Windows.Forms.TextBox textBoxC43;
        private System.Windows.Forms.TextBox textBoxC42;
        private System.Windows.Forms.TextBox textBoxC41;
        private System.Windows.Forms.TextBox textBoxC40;
        private System.Windows.Forms.TextBox textBoxC39;
        private System.Windows.Forms.TextBox textBoxC38;
        private System.Windows.Forms.TextBox textBoxC37;
        private System.Windows.Forms.TextBox textBoxC34;
        private System.Windows.Forms.TextBox textBoxC33;
        private System.Windows.Forms.TextBox textBoxC32;
        private System.Windows.Forms.TextBox textBoxC31;
        private System.Windows.Forms.TextBox textBoxC30;
        private System.Windows.Forms.TextBox textBoxC29;
        private System.Windows.Forms.TextBox textBoxC28;
        private System.Windows.Forms.TextBox textBoxC27;
        private System.Windows.Forms.TextBox textBoxC26;
        private System.Windows.Forms.TextBox textBoxC25;
        private System.Windows.Forms.TextBox textBoxC22;
        private System.Windows.Forms.TextBox textBoxC21;
        private System.Windows.Forms.TextBox textBoxC20;
        private System.Windows.Forms.TextBox textBoxC19;
        private System.Windows.Forms.TextBox textBoxC18;
        private System.Windows.Forms.TextBox textBoxC17;
        private System.Windows.Forms.TextBox textBoxC16;
        private System.Windows.Forms.TextBox textBoxC15;
        private System.Windows.Forms.TextBox textBoxC14;
        private System.Windows.Forms.TextBox textBoxC13;
    }
}