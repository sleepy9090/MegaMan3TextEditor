﻿namespace MegaMan3TextEditor {
    partial class Form1 {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxName8 = new System.Windows.Forms.TextBox();
            this.textBoxName7 = new System.Windows.Forms.TextBox();
            this.textBoxName6 = new System.Windows.Forms.TextBox();
            this.textBoxName5 = new System.Windows.Forms.TextBox();
            this.textBoxName4 = new System.Windows.Forms.TextBox();
            this.textBoxName3 = new System.Windows.Forms.TextBox();
            this.textBoxName2 = new System.Windows.Forms.TextBox();
            this.textBoxName1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordGameoverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.weaponNamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beginningIntroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drLightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.endingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.robotListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mM3RobotsCreatorsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelFilename = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonOpenRom = new System.Windows.Forms.Button();
            this.textBoxFilename = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxName25 = new System.Windows.Forms.TextBox();
            this.textBoxName24 = new System.Windows.Forms.TextBox();
            this.textBoxName23 = new System.Windows.Forms.TextBox();
            this.textBoxName22 = new System.Windows.Forms.TextBox();
            this.textBoxName21 = new System.Windows.Forms.TextBox();
            this.textBoxName9 = new System.Windows.Forms.TextBox();
            this.textBoxName12 = new System.Windows.Forms.TextBox();
            this.textBoxName10 = new System.Windows.Forms.TextBox();
            this.textBoxName11 = new System.Windows.Forms.TextBox();
            this.textBoxName20 = new System.Windows.Forms.TextBox();
            this.textBoxName19 = new System.Windows.Forms.TextBox();
            this.textBoxName18 = new System.Windows.Forms.TextBox();
            this.textBoxName17 = new System.Windows.Forms.TextBox();
            this.textBoxName16 = new System.Windows.Forms.TextBox();
            this.textBoxName15 = new System.Windows.Forms.TextBox();
            this.textBoxName14 = new System.Windows.Forms.TextBox();
            this.textBoxName13 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxName8);
            this.groupBox1.Controls.Add(this.textBoxName7);
            this.groupBox1.Controls.Add(this.textBoxName6);
            this.groupBox1.Controls.Add(this.textBoxName5);
            this.groupBox1.Controls.Add(this.textBoxName4);
            this.groupBox1.Controls.Add(this.textBoxName3);
            this.groupBox1.Controls.Add(this.textBoxName2);
            this.groupBox1.Controls.Add(this.textBoxName1);
            this.groupBox1.Location = new System.Drawing.Point(12, 237);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(437, 80);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stage Select #2";
            // 
            // textBoxName8
            // 
            this.textBoxName8.Location = new System.Drawing.Point(327, 45);
            this.textBoxName8.Name = "textBoxName8";
            this.textBoxName8.Size = new System.Drawing.Size(100, 20);
            this.textBoxName8.TabIndex = 8;
            // 
            // textBoxName7
            // 
            this.textBoxName7.Location = new System.Drawing.Point(221, 45);
            this.textBoxName7.Name = "textBoxName7";
            this.textBoxName7.Size = new System.Drawing.Size(100, 20);
            this.textBoxName7.TabIndex = 7;
            // 
            // textBoxName6
            // 
            this.textBoxName6.Location = new System.Drawing.Point(115, 45);
            this.textBoxName6.Name = "textBoxName6";
            this.textBoxName6.Size = new System.Drawing.Size(100, 20);
            this.textBoxName6.TabIndex = 6;
            // 
            // textBoxName5
            // 
            this.textBoxName5.Location = new System.Drawing.Point(9, 45);
            this.textBoxName5.Name = "textBoxName5";
            this.textBoxName5.Size = new System.Drawing.Size(100, 20);
            this.textBoxName5.TabIndex = 5;
            // 
            // textBoxName4
            // 
            this.textBoxName4.Location = new System.Drawing.Point(327, 19);
            this.textBoxName4.Name = "textBoxName4";
            this.textBoxName4.Size = new System.Drawing.Size(100, 20);
            this.textBoxName4.TabIndex = 4;
            // 
            // textBoxName3
            // 
            this.textBoxName3.Location = new System.Drawing.Point(221, 19);
            this.textBoxName3.Name = "textBoxName3";
            this.textBoxName3.Size = new System.Drawing.Size(100, 20);
            this.textBoxName3.TabIndex = 3;
            // 
            // textBoxName2
            // 
            this.textBoxName2.Location = new System.Drawing.Point(115, 19);
            this.textBoxName2.Name = "textBoxName2";
            this.textBoxName2.Size = new System.Drawing.Size(100, 20);
            this.textBoxName2.TabIndex = 2;
            // 
            // textBoxName1
            // 
            this.textBoxName1.Location = new System.Drawing.Point(9, 19);
            this.textBoxName1.Name = "textBoxName1";
            this.textBoxName1.Size = new System.Drawing.Size(100, 20);
            this.textBoxName1.TabIndex = 1;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(364, 323);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 1;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(462, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.openToolStripMenuItem.Text = "&Open ROM";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(130, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.exitToolStripMenuItem.Text = "&Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.passwordGameoverToolStripMenuItem,
            this.weaponNamesToolStripMenuItem,
            this.beginningIntroToolStripMenuItem,
            this.drLightToolStripMenuItem,
            this.endingToolStripMenuItem,
            this.robotListToolStripMenuItem,
            this.mM3RobotsCreatorsToolStripMenuItem,
            this.creditsToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "&Edit";
            // 
            // passwordGameoverToolStripMenuItem
            // 
            this.passwordGameoverToolStripMenuItem.Name = "passwordGameoverToolStripMenuItem";
            this.passwordGameoverToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.passwordGameoverToolStripMenuItem.Text = "&Password/Gameover";
            this.passwordGameoverToolStripMenuItem.Click += new System.EventHandler(this.updateTextToolStripMenuItem_Click);
            // 
            // weaponNamesToolStripMenuItem
            // 
            this.weaponNamesToolStripMenuItem.Name = "weaponNamesToolStripMenuItem";
            this.weaponNamesToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.weaponNamesToolStripMenuItem.Text = "&Weapon Names";
            this.weaponNamesToolStripMenuItem.Click += new System.EventHandler(this.weaponNamesToolStripMenuItem_Click);
            // 
            // beginningIntroToolStripMenuItem
            // 
            this.beginningIntroToolStripMenuItem.Name = "beginningIntroToolStripMenuItem";
            this.beginningIntroToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.beginningIntroToolStripMenuItem.Text = "&Beginning Intro";
            this.beginningIntroToolStripMenuItem.Click += new System.EventHandler(this.beginningIntroToolStripMenuItem_Click);
            // 
            // drLightToolStripMenuItem
            // 
            this.drLightToolStripMenuItem.Name = "drLightToolStripMenuItem";
            this.drLightToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.drLightToolStripMenuItem.Text = "&Dr. Light";
            this.drLightToolStripMenuItem.Click += new System.EventHandler(this.drLightToolStripMenuItem_Click);
            // 
            // endingToolStripMenuItem
            // 
            this.endingToolStripMenuItem.Name = "endingToolStripMenuItem";
            this.endingToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.endingToolStripMenuItem.Text = "&Ending";
            this.endingToolStripMenuItem.Click += new System.EventHandler(this.endingToolStripMenuItem_Click);
            // 
            // robotListToolStripMenuItem
            // 
            this.robotListToolStripMenuItem.Name = "robotListToolStripMenuItem";
            this.robotListToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.robotListToolStripMenuItem.Text = "&Robot List (Dr. Light)";
            this.robotListToolStripMenuItem.Click += new System.EventHandler(this.robotListToolStripMenuItem_Click);
            // 
            // mM3RobotsCreatorsToolStripMenuItem
            // 
            this.mM3RobotsCreatorsToolStripMenuItem.Name = "mM3RobotsCreatorsToolStripMenuItem";
            this.mM3RobotsCreatorsToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.mM3RobotsCreatorsToolStripMenuItem.Text = "&MM3 Robots/Creators";
            this.mM3RobotsCreatorsToolStripMenuItem.Click += new System.EventHandler(this.mM3RobotsCreatorsToolStripMenuItem_Click);
            // 
            // creditsToolStripMenuItem
            // 
            this.creditsToolStripMenuItem.Name = "creditsToolStripMenuItem";
            this.creditsToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.creditsToolStripMenuItem.Text = "&Credits";
            this.creditsToolStripMenuItem.Click += new System.EventHandler(this.creditsToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // labelFilename
            // 
            this.labelFilename.AutoSize = true;
            this.labelFilename.Location = new System.Drawing.Point(6, 16);
            this.labelFilename.Name = "labelFilename";
            this.labelFilename.Size = new System.Drawing.Size(52, 13);
            this.labelFilename.TabIndex = 0;
            this.labelFilename.Text = "Filename:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonOpenRom);
            this.groupBox2.Controls.Add(this.textBoxFilename);
            this.groupBox2.Controls.Add(this.labelFilename);
            this.groupBox2.Location = new System.Drawing.Point(12, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(437, 44);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // buttonOpenRom
            // 
            this.buttonOpenRom.Location = new System.Drawing.Point(352, 11);
            this.buttonOpenRom.Name = "buttonOpenRom";
            this.buttonOpenRom.Size = new System.Drawing.Size(75, 23);
            this.buttonOpenRom.TabIndex = 1;
            this.buttonOpenRom.Text = "&Open ROM";
            this.buttonOpenRom.UseVisualStyleBackColor = true;
            this.buttonOpenRom.Click += new System.EventHandler(this.buttonOpenRom_Click);
            // 
            // textBoxFilename
            // 
            this.textBoxFilename.Location = new System.Drawing.Point(64, 13);
            this.textBoxFilename.Name = "textBoxFilename";
            this.textBoxFilename.ReadOnly = true;
            this.textBoxFilename.Size = new System.Drawing.Size(282, 20);
            this.textBoxFilename.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBoxName25);
            this.groupBox3.Controls.Add(this.textBoxName24);
            this.groupBox3.Controls.Add(this.textBoxName23);
            this.groupBox3.Controls.Add(this.textBoxName22);
            this.groupBox3.Controls.Add(this.textBoxName21);
            this.groupBox3.Controls.Add(this.textBoxName9);
            this.groupBox3.Controls.Add(this.textBoxName12);
            this.groupBox3.Controls.Add(this.textBoxName10);
            this.groupBox3.Controls.Add(this.textBoxName11);
            this.groupBox3.Controls.Add(this.textBoxName20);
            this.groupBox3.Controls.Add(this.textBoxName19);
            this.groupBox3.Controls.Add(this.textBoxName18);
            this.groupBox3.Controls.Add(this.textBoxName17);
            this.groupBox3.Controls.Add(this.textBoxName16);
            this.groupBox3.Controls.Add(this.textBoxName15);
            this.groupBox3.Controls.Add(this.textBoxName14);
            this.groupBox3.Controls.Add(this.textBoxName13);
            this.groupBox3.Location = new System.Drawing.Point(13, 77);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(437, 154);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Stage Select #1";
            // 
            // textBoxName25
            // 
            this.textBoxName25.Location = new System.Drawing.Point(327, 97);
            this.textBoxName25.Name = "textBoxName25";
            this.textBoxName25.Size = new System.Drawing.Size(100, 20);
            this.textBoxName25.TabIndex = 16;
            // 
            // textBoxName24
            // 
            this.textBoxName24.Location = new System.Drawing.Point(115, 97);
            this.textBoxName24.Name = "textBoxName24";
            this.textBoxName24.Size = new System.Drawing.Size(100, 20);
            this.textBoxName24.TabIndex = 14;
            // 
            // textBoxName23
            // 
            this.textBoxName23.Location = new System.Drawing.Point(327, 71);
            this.textBoxName23.Name = "textBoxName23";
            this.textBoxName23.Size = new System.Drawing.Size(100, 20);
            this.textBoxName23.TabIndex = 12;
            // 
            // textBoxName22
            // 
            this.textBoxName22.Location = new System.Drawing.Point(221, 97);
            this.textBoxName22.Name = "textBoxName22";
            this.textBoxName22.Size = new System.Drawing.Size(100, 20);
            this.textBoxName22.TabIndex = 15;
            // 
            // textBoxName21
            // 
            this.textBoxName21.Location = new System.Drawing.Point(9, 97);
            this.textBoxName21.Name = "textBoxName21";
            this.textBoxName21.Size = new System.Drawing.Size(100, 20);
            this.textBoxName21.TabIndex = 13;
            // 
            // textBoxName9
            // 
            this.textBoxName9.Location = new System.Drawing.Point(9, 123);
            this.textBoxName9.Name = "textBoxName9";
            this.textBoxName9.Size = new System.Drawing.Size(100, 20);
            this.textBoxName9.TabIndex = 17;
            // 
            // textBoxName12
            // 
            this.textBoxName12.Location = new System.Drawing.Point(9, 45);
            this.textBoxName12.Name = "textBoxName12";
            this.textBoxName12.Size = new System.Drawing.Size(100, 20);
            this.textBoxName12.TabIndex = 5;
            // 
            // textBoxName10
            // 
            this.textBoxName10.Location = new System.Drawing.Point(9, 19);
            this.textBoxName10.Name = "textBoxName10";
            this.textBoxName10.Size = new System.Drawing.Size(100, 20);
            this.textBoxName10.TabIndex = 1;
            // 
            // textBoxName11
            // 
            this.textBoxName11.Location = new System.Drawing.Point(221, 19);
            this.textBoxName11.Name = "textBoxName11";
            this.textBoxName11.Size = new System.Drawing.Size(100, 20);
            this.textBoxName11.TabIndex = 3;
            // 
            // textBoxName20
            // 
            this.textBoxName20.Location = new System.Drawing.Point(221, 71);
            this.textBoxName20.Name = "textBoxName20";
            this.textBoxName20.Size = new System.Drawing.Size(100, 20);
            this.textBoxName20.TabIndex = 11;
            // 
            // textBoxName19
            // 
            this.textBoxName19.Location = new System.Drawing.Point(115, 71);
            this.textBoxName19.Name = "textBoxName19";
            this.textBoxName19.Size = new System.Drawing.Size(100, 20);
            this.textBoxName19.TabIndex = 10;
            // 
            // textBoxName18
            // 
            this.textBoxName18.Location = new System.Drawing.Point(327, 45);
            this.textBoxName18.Name = "textBoxName18";
            this.textBoxName18.Size = new System.Drawing.Size(100, 20);
            this.textBoxName18.TabIndex = 8;
            // 
            // textBoxName17
            // 
            this.textBoxName17.Location = new System.Drawing.Point(9, 71);
            this.textBoxName17.Name = "textBoxName17";
            this.textBoxName17.Size = new System.Drawing.Size(100, 20);
            this.textBoxName17.TabIndex = 9;
            // 
            // textBoxName16
            // 
            this.textBoxName16.Location = new System.Drawing.Point(221, 45);
            this.textBoxName16.Name = "textBoxName16";
            this.textBoxName16.Size = new System.Drawing.Size(100, 20);
            this.textBoxName16.TabIndex = 7;
            // 
            // textBoxName15
            // 
            this.textBoxName15.Location = new System.Drawing.Point(115, 45);
            this.textBoxName15.Name = "textBoxName15";
            this.textBoxName15.Size = new System.Drawing.Size(100, 20);
            this.textBoxName15.TabIndex = 6;
            // 
            // textBoxName14
            // 
            this.textBoxName14.Location = new System.Drawing.Point(327, 19);
            this.textBoxName14.Name = "textBoxName14";
            this.textBoxName14.Size = new System.Drawing.Size(100, 20);
            this.textBoxName14.TabIndex = 4;
            // 
            // textBoxName13
            // 
            this.textBoxName13.Location = new System.Drawing.Point(115, 19);
            this.textBoxName13.Name = "textBoxName13";
            this.textBoxName13.Size = new System.Drawing.Size(100, 20);
            this.textBoxName13.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 351);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.buttonUpdateText);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwordGameoverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label labelFilename;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonOpenRom;
        private System.Windows.Forms.TextBox textBoxFilename;
        private System.Windows.Forms.TextBox textBoxName1;
        private System.Windows.Forms.Button buttonUpdateText;
        private System.Windows.Forms.TextBox textBoxName2;
        private System.Windows.Forms.TextBox textBoxName8;
        private System.Windows.Forms.TextBox textBoxName7;
        private System.Windows.Forms.TextBox textBoxName6;
        private System.Windows.Forms.TextBox textBoxName5;
        private System.Windows.Forms.TextBox textBoxName4;
        private System.Windows.Forms.TextBox textBoxName3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBoxName16;
        private System.Windows.Forms.TextBox textBoxName15;
        private System.Windows.Forms.TextBox textBoxName14;
        private System.Windows.Forms.TextBox textBoxName13;
        private System.Windows.Forms.TextBox textBoxName12;
        private System.Windows.Forms.TextBox textBoxName11;
        private System.Windows.Forms.TextBox textBoxName10;
        private System.Windows.Forms.TextBox textBoxName9;
        private System.Windows.Forms.ToolStripMenuItem weaponNamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beginningIntroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drLightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem endingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxName25;
        private System.Windows.Forms.TextBox textBoxName24;
        private System.Windows.Forms.TextBox textBoxName23;
        private System.Windows.Forms.TextBox textBoxName22;
        private System.Windows.Forms.TextBox textBoxName21;
        private System.Windows.Forms.TextBox textBoxName20;
        private System.Windows.Forms.TextBox textBoxName19;
        private System.Windows.Forms.TextBox textBoxName18;
        private System.Windows.Forms.TextBox textBoxName17;
        private System.Windows.Forms.ToolStripMenuItem robotListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mM3RobotsCreatorsToolStripMenuItem;
    }
}

