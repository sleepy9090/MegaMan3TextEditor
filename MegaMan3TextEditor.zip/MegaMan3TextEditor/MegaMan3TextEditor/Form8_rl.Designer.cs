﻿namespace MegaMan3TextEditor {
    partial class Form8_rl {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8_rl));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxRL40 = new System.Windows.Forms.TextBox();
            this.textBoxRL39 = new System.Windows.Forms.TextBox();
            this.textBoxRL38 = new System.Windows.Forms.TextBox();
            this.textBoxRL37 = new System.Windows.Forms.TextBox();
            this.textBoxRL36 = new System.Windows.Forms.TextBox();
            this.textBoxRL35 = new System.Windows.Forms.TextBox();
            this.textBoxRL34 = new System.Windows.Forms.TextBox();
            this.textBoxRL33 = new System.Windows.Forms.TextBox();
            this.textBoxRL32 = new System.Windows.Forms.TextBox();
            this.textBoxRL31 = new System.Windows.Forms.TextBox();
            this.textBoxRL30 = new System.Windows.Forms.TextBox();
            this.textBoxRL29 = new System.Windows.Forms.TextBox();
            this.textBoxRL28 = new System.Windows.Forms.TextBox();
            this.textBoxRL27 = new System.Windows.Forms.TextBox();
            this.textBoxRL26 = new System.Windows.Forms.TextBox();
            this.textBoxRL25 = new System.Windows.Forms.TextBox();
            this.textBoxRL24 = new System.Windows.Forms.TextBox();
            this.textBoxRL23 = new System.Windows.Forms.TextBox();
            this.textBoxRL22 = new System.Windows.Forms.TextBox();
            this.textBoxRL21 = new System.Windows.Forms.TextBox();
            this.textBoxRL20 = new System.Windows.Forms.TextBox();
            this.textBoxRL19 = new System.Windows.Forms.TextBox();
            this.textBoxRL18 = new System.Windows.Forms.TextBox();
            this.textBoxRL17 = new System.Windows.Forms.TextBox();
            this.textBoxRL16 = new System.Windows.Forms.TextBox();
            this.textBoxRL15 = new System.Windows.Forms.TextBox();
            this.textBoxRL14 = new System.Windows.Forms.TextBox();
            this.textBoxRL13 = new System.Windows.Forms.TextBox();
            this.textBoxRL12 = new System.Windows.Forms.TextBox();
            this.textBoxRL11 = new System.Windows.Forms.TextBox();
            this.textBoxRL10 = new System.Windows.Forms.TextBox();
            this.textBoxRL9 = new System.Windows.Forms.TextBox();
            this.textBoxRL8 = new System.Windows.Forms.TextBox();
            this.textBoxRL7 = new System.Windows.Forms.TextBox();
            this.textBoxRL6 = new System.Windows.Forms.TextBox();
            this.textBoxRL5 = new System.Windows.Forms.TextBox();
            this.textBoxRL4 = new System.Windows.Forms.TextBox();
            this.textBoxRL3 = new System.Windows.Forms.TextBox();
            this.textBoxRL2 = new System.Windows.Forms.TextBox();
            this.textBoxRL1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxRL40);
            this.groupBox1.Controls.Add(this.textBoxRL39);
            this.groupBox1.Controls.Add(this.textBoxRL38);
            this.groupBox1.Controls.Add(this.textBoxRL37);
            this.groupBox1.Controls.Add(this.textBoxRL36);
            this.groupBox1.Controls.Add(this.textBoxRL35);
            this.groupBox1.Controls.Add(this.textBoxRL34);
            this.groupBox1.Controls.Add(this.textBoxRL33);
            this.groupBox1.Controls.Add(this.textBoxRL32);
            this.groupBox1.Controls.Add(this.textBoxRL31);
            this.groupBox1.Controls.Add(this.textBoxRL30);
            this.groupBox1.Controls.Add(this.textBoxRL29);
            this.groupBox1.Controls.Add(this.textBoxRL28);
            this.groupBox1.Controls.Add(this.textBoxRL27);
            this.groupBox1.Controls.Add(this.textBoxRL26);
            this.groupBox1.Controls.Add(this.textBoxRL25);
            this.groupBox1.Controls.Add(this.textBoxRL24);
            this.groupBox1.Controls.Add(this.textBoxRL23);
            this.groupBox1.Controls.Add(this.textBoxRL22);
            this.groupBox1.Controls.Add(this.textBoxRL21);
            this.groupBox1.Controls.Add(this.textBoxRL20);
            this.groupBox1.Controls.Add(this.textBoxRL19);
            this.groupBox1.Controls.Add(this.textBoxRL18);
            this.groupBox1.Controls.Add(this.textBoxRL17);
            this.groupBox1.Controls.Add(this.textBoxRL16);
            this.groupBox1.Controls.Add(this.textBoxRL15);
            this.groupBox1.Controls.Add(this.textBoxRL14);
            this.groupBox1.Controls.Add(this.textBoxRL13);
            this.groupBox1.Controls.Add(this.textBoxRL12);
            this.groupBox1.Controls.Add(this.textBoxRL11);
            this.groupBox1.Controls.Add(this.textBoxRL10);
            this.groupBox1.Controls.Add(this.textBoxRL9);
            this.groupBox1.Controls.Add(this.textBoxRL8);
            this.groupBox1.Controls.Add(this.textBoxRL7);
            this.groupBox1.Controls.Add(this.textBoxRL6);
            this.groupBox1.Controls.Add(this.textBoxRL5);
            this.groupBox1.Controls.Add(this.textBoxRL4);
            this.groupBox1.Controls.Add(this.textBoxRL3);
            this.groupBox1.Controls.Add(this.textBoxRL2);
            this.groupBox1.Controls.Add(this.textBoxRL1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(434, 284);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Robot List";
            // 
            // textBoxRL40
            // 
            this.textBoxRL40.Location = new System.Drawing.Point(324, 253);
            this.textBoxRL40.Name = "textBoxRL40";
            this.textBoxRL40.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL40.TabIndex = 39;
            // 
            // textBoxRL39
            // 
            this.textBoxRL39.Location = new System.Drawing.Point(324, 227);
            this.textBoxRL39.Name = "textBoxRL39";
            this.textBoxRL39.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL39.TabIndex = 38;
            // 
            // textBoxRL38
            // 
            this.textBoxRL38.Location = new System.Drawing.Point(324, 201);
            this.textBoxRL38.Name = "textBoxRL38";
            this.textBoxRL38.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL38.TabIndex = 37;
            // 
            // textBoxRL37
            // 
            this.textBoxRL37.Location = new System.Drawing.Point(324, 175);
            this.textBoxRL37.Name = "textBoxRL37";
            this.textBoxRL37.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL37.TabIndex = 36;
            // 
            // textBoxRL36
            // 
            this.textBoxRL36.Location = new System.Drawing.Point(324, 149);
            this.textBoxRL36.Name = "textBoxRL36";
            this.textBoxRL36.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL36.TabIndex = 35;
            // 
            // textBoxRL35
            // 
            this.textBoxRL35.Location = new System.Drawing.Point(324, 123);
            this.textBoxRL35.Name = "textBoxRL35";
            this.textBoxRL35.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL35.TabIndex = 34;
            // 
            // textBoxRL34
            // 
            this.textBoxRL34.Location = new System.Drawing.Point(324, 97);
            this.textBoxRL34.Name = "textBoxRL34";
            this.textBoxRL34.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL34.TabIndex = 33;
            // 
            // textBoxRL33
            // 
            this.textBoxRL33.Location = new System.Drawing.Point(324, 71);
            this.textBoxRL33.Name = "textBoxRL33";
            this.textBoxRL33.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL33.TabIndex = 32;
            // 
            // textBoxRL32
            // 
            this.textBoxRL32.Location = new System.Drawing.Point(324, 45);
            this.textBoxRL32.Name = "textBoxRL32";
            this.textBoxRL32.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL32.TabIndex = 31;
            // 
            // textBoxRL31
            // 
            this.textBoxRL31.Location = new System.Drawing.Point(324, 19);
            this.textBoxRL31.Name = "textBoxRL31";
            this.textBoxRL31.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL31.TabIndex = 30;
            // 
            // textBoxRL30
            // 
            this.textBoxRL30.Location = new System.Drawing.Point(218, 253);
            this.textBoxRL30.Name = "textBoxRL30";
            this.textBoxRL30.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL30.TabIndex = 29;
            // 
            // textBoxRL29
            // 
            this.textBoxRL29.Location = new System.Drawing.Point(218, 227);
            this.textBoxRL29.Name = "textBoxRL29";
            this.textBoxRL29.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL29.TabIndex = 28;
            // 
            // textBoxRL28
            // 
            this.textBoxRL28.Location = new System.Drawing.Point(218, 201);
            this.textBoxRL28.Name = "textBoxRL28";
            this.textBoxRL28.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL28.TabIndex = 27;
            // 
            // textBoxRL27
            // 
            this.textBoxRL27.Location = new System.Drawing.Point(218, 175);
            this.textBoxRL27.Name = "textBoxRL27";
            this.textBoxRL27.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL27.TabIndex = 26;
            // 
            // textBoxRL26
            // 
            this.textBoxRL26.Location = new System.Drawing.Point(218, 149);
            this.textBoxRL26.Name = "textBoxRL26";
            this.textBoxRL26.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL26.TabIndex = 25;
            // 
            // textBoxRL25
            // 
            this.textBoxRL25.Location = new System.Drawing.Point(218, 123);
            this.textBoxRL25.Name = "textBoxRL25";
            this.textBoxRL25.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL25.TabIndex = 24;
            // 
            // textBoxRL24
            // 
            this.textBoxRL24.Location = new System.Drawing.Point(218, 97);
            this.textBoxRL24.Name = "textBoxRL24";
            this.textBoxRL24.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL24.TabIndex = 23;
            // 
            // textBoxRL23
            // 
            this.textBoxRL23.Location = new System.Drawing.Point(218, 71);
            this.textBoxRL23.Name = "textBoxRL23";
            this.textBoxRL23.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL23.TabIndex = 22;
            // 
            // textBoxRL22
            // 
            this.textBoxRL22.Location = new System.Drawing.Point(218, 45);
            this.textBoxRL22.Name = "textBoxRL22";
            this.textBoxRL22.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL22.TabIndex = 21;
            // 
            // textBoxRL21
            // 
            this.textBoxRL21.Location = new System.Drawing.Point(218, 19);
            this.textBoxRL21.Name = "textBoxRL21";
            this.textBoxRL21.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL21.TabIndex = 20;
            // 
            // textBoxRL20
            // 
            this.textBoxRL20.Location = new System.Drawing.Point(112, 253);
            this.textBoxRL20.Name = "textBoxRL20";
            this.textBoxRL20.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL20.TabIndex = 19;
            // 
            // textBoxRL19
            // 
            this.textBoxRL19.Location = new System.Drawing.Point(112, 227);
            this.textBoxRL19.Name = "textBoxRL19";
            this.textBoxRL19.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL19.TabIndex = 18;
            // 
            // textBoxRL18
            // 
            this.textBoxRL18.Location = new System.Drawing.Point(112, 201);
            this.textBoxRL18.Name = "textBoxRL18";
            this.textBoxRL18.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL18.TabIndex = 17;
            // 
            // textBoxRL17
            // 
            this.textBoxRL17.Location = new System.Drawing.Point(112, 175);
            this.textBoxRL17.Name = "textBoxRL17";
            this.textBoxRL17.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL17.TabIndex = 16;
            // 
            // textBoxRL16
            // 
            this.textBoxRL16.Location = new System.Drawing.Point(112, 149);
            this.textBoxRL16.Name = "textBoxRL16";
            this.textBoxRL16.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL16.TabIndex = 15;
            // 
            // textBoxRL15
            // 
            this.textBoxRL15.Location = new System.Drawing.Point(112, 123);
            this.textBoxRL15.Name = "textBoxRL15";
            this.textBoxRL15.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL15.TabIndex = 14;
            // 
            // textBoxRL14
            // 
            this.textBoxRL14.Location = new System.Drawing.Point(112, 97);
            this.textBoxRL14.Name = "textBoxRL14";
            this.textBoxRL14.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL14.TabIndex = 13;
            // 
            // textBoxRL13
            // 
            this.textBoxRL13.Location = new System.Drawing.Point(112, 71);
            this.textBoxRL13.Name = "textBoxRL13";
            this.textBoxRL13.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL13.TabIndex = 12;
            // 
            // textBoxRL12
            // 
            this.textBoxRL12.Location = new System.Drawing.Point(112, 45);
            this.textBoxRL12.Name = "textBoxRL12";
            this.textBoxRL12.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL12.TabIndex = 11;
            // 
            // textBoxRL11
            // 
            this.textBoxRL11.Location = new System.Drawing.Point(112, 19);
            this.textBoxRL11.Name = "textBoxRL11";
            this.textBoxRL11.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL11.TabIndex = 10;
            // 
            // textBoxRL10
            // 
            this.textBoxRL10.Location = new System.Drawing.Point(6, 253);
            this.textBoxRL10.Name = "textBoxRL10";
            this.textBoxRL10.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL10.TabIndex = 9;
            // 
            // textBoxRL9
            // 
            this.textBoxRL9.Location = new System.Drawing.Point(6, 227);
            this.textBoxRL9.Name = "textBoxRL9";
            this.textBoxRL9.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL9.TabIndex = 8;
            // 
            // textBoxRL8
            // 
            this.textBoxRL8.Location = new System.Drawing.Point(6, 201);
            this.textBoxRL8.Name = "textBoxRL8";
            this.textBoxRL8.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL8.TabIndex = 7;
            // 
            // textBoxRL7
            // 
            this.textBoxRL7.Location = new System.Drawing.Point(6, 175);
            this.textBoxRL7.Name = "textBoxRL7";
            this.textBoxRL7.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL7.TabIndex = 6;
            // 
            // textBoxRL6
            // 
            this.textBoxRL6.Location = new System.Drawing.Point(6, 149);
            this.textBoxRL6.Name = "textBoxRL6";
            this.textBoxRL6.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL6.TabIndex = 5;
            // 
            // textBoxRL5
            // 
            this.textBoxRL5.Location = new System.Drawing.Point(6, 123);
            this.textBoxRL5.Name = "textBoxRL5";
            this.textBoxRL5.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL5.TabIndex = 4;
            // 
            // textBoxRL4
            // 
            this.textBoxRL4.Location = new System.Drawing.Point(6, 97);
            this.textBoxRL4.Name = "textBoxRL4";
            this.textBoxRL4.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL4.TabIndex = 3;
            // 
            // textBoxRL3
            // 
            this.textBoxRL3.Location = new System.Drawing.Point(6, 71);
            this.textBoxRL3.Name = "textBoxRL3";
            this.textBoxRL3.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL3.TabIndex = 2;
            // 
            // textBoxRL2
            // 
            this.textBoxRL2.Location = new System.Drawing.Point(6, 45);
            this.textBoxRL2.Name = "textBoxRL2";
            this.textBoxRL2.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL2.TabIndex = 1;
            // 
            // textBoxRL1
            // 
            this.textBoxRL1.Location = new System.Drawing.Point(6, 19);
            this.textBoxRL1.Name = "textBoxRL1";
            this.textBoxRL1.Size = new System.Drawing.Size(100, 20);
            this.textBoxRL1.TabIndex = 0;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(361, 302);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 1;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // Form8_rl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 332);
            this.Controls.Add(this.buttonUpdateText);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form8_rl";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form8_rl_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonUpdateText;
        private System.Windows.Forms.TextBox textBoxRL40;
        private System.Windows.Forms.TextBox textBoxRL39;
        private System.Windows.Forms.TextBox textBoxRL38;
        private System.Windows.Forms.TextBox textBoxRL37;
        private System.Windows.Forms.TextBox textBoxRL36;
        private System.Windows.Forms.TextBox textBoxRL35;
        private System.Windows.Forms.TextBox textBoxRL34;
        private System.Windows.Forms.TextBox textBoxRL33;
        private System.Windows.Forms.TextBox textBoxRL32;
        private System.Windows.Forms.TextBox textBoxRL31;
        private System.Windows.Forms.TextBox textBoxRL30;
        private System.Windows.Forms.TextBox textBoxRL29;
        private System.Windows.Forms.TextBox textBoxRL28;
        private System.Windows.Forms.TextBox textBoxRL27;
        private System.Windows.Forms.TextBox textBoxRL26;
        private System.Windows.Forms.TextBox textBoxRL25;
        private System.Windows.Forms.TextBox textBoxRL24;
        private System.Windows.Forms.TextBox textBoxRL23;
        private System.Windows.Forms.TextBox textBoxRL22;
        private System.Windows.Forms.TextBox textBoxRL21;
        private System.Windows.Forms.TextBox textBoxRL20;
        private System.Windows.Forms.TextBox textBoxRL19;
        private System.Windows.Forms.TextBox textBoxRL18;
        private System.Windows.Forms.TextBox textBoxRL17;
        private System.Windows.Forms.TextBox textBoxRL16;
        private System.Windows.Forms.TextBox textBoxRL15;
        private System.Windows.Forms.TextBox textBoxRL14;
        private System.Windows.Forms.TextBox textBoxRL13;
        private System.Windows.Forms.TextBox textBoxRL12;
        private System.Windows.Forms.TextBox textBoxRL11;
        private System.Windows.Forms.TextBox textBoxRL10;
        private System.Windows.Forms.TextBox textBoxRL9;
        private System.Windows.Forms.TextBox textBoxRL8;
        private System.Windows.Forms.TextBox textBoxRL7;
        private System.Windows.Forms.TextBox textBoxRL6;
        private System.Windows.Forms.TextBox textBoxRL5;
        private System.Windows.Forms.TextBox textBoxRL4;
        private System.Windows.Forms.TextBox textBoxRL3;
        private System.Windows.Forms.TextBox textBoxRL2;
        private System.Windows.Forms.TextBox textBoxRL1;
    }
}