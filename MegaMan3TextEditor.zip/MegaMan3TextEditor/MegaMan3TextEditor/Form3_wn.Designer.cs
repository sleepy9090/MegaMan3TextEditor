﻿namespace MegaMan3TextEditor {
    partial class Form3_wn {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3_wn));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxWN13 = new System.Windows.Forms.TextBox();
            this.textBoxWN12 = new System.Windows.Forms.TextBox();
            this.textBoxWN11 = new System.Windows.Forms.TextBox();
            this.textBoxWN10 = new System.Windows.Forms.TextBox();
            this.textBoxWN9 = new System.Windows.Forms.TextBox();
            this.textBoxWN8 = new System.Windows.Forms.TextBox();
            this.textBoxWN7 = new System.Windows.Forms.TextBox();
            this.textBoxWN6 = new System.Windows.Forms.TextBox();
            this.textBoxWN5 = new System.Windows.Forms.TextBox();
            this.textBoxWN4 = new System.Windows.Forms.TextBox();
            this.textBoxWN3 = new System.Windows.Forms.TextBox();
            this.textBoxWN2 = new System.Windows.Forms.TextBox();
            this.textBoxWN1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxWN13);
            this.groupBox1.Controls.Add(this.textBoxWN12);
            this.groupBox1.Controls.Add(this.textBoxWN11);
            this.groupBox1.Controls.Add(this.textBoxWN10);
            this.groupBox1.Controls.Add(this.textBoxWN9);
            this.groupBox1.Controls.Add(this.textBoxWN8);
            this.groupBox1.Controls.Add(this.textBoxWN7);
            this.groupBox1.Controls.Add(this.textBoxWN6);
            this.groupBox1.Controls.Add(this.textBoxWN5);
            this.groupBox1.Controls.Add(this.textBoxWN4);
            this.groupBox1.Controls.Add(this.textBoxWN3);
            this.groupBox1.Controls.Add(this.textBoxWN2);
            this.groupBox1.Controls.Add(this.textBoxWN1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(438, 126);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Weapon Names";
            // 
            // textBoxWN13
            // 
            this.textBoxWN13.Location = new System.Drawing.Point(6, 97);
            this.textBoxWN13.Name = "textBoxWN13";
            this.textBoxWN13.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN13.TabIndex = 12;
            // 
            // textBoxWN12
            // 
            this.textBoxWN12.Location = new System.Drawing.Point(324, 71);
            this.textBoxWN12.Name = "textBoxWN12";
            this.textBoxWN12.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN12.TabIndex = 11;
            // 
            // textBoxWN11
            // 
            this.textBoxWN11.Location = new System.Drawing.Point(218, 71);
            this.textBoxWN11.Name = "textBoxWN11";
            this.textBoxWN11.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN11.TabIndex = 10;
            // 
            // textBoxWN10
            // 
            this.textBoxWN10.Location = new System.Drawing.Point(112, 71);
            this.textBoxWN10.Name = "textBoxWN10";
            this.textBoxWN10.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN10.TabIndex = 9;
            // 
            // textBoxWN9
            // 
            this.textBoxWN9.Location = new System.Drawing.Point(6, 71);
            this.textBoxWN9.Name = "textBoxWN9";
            this.textBoxWN9.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN9.TabIndex = 8;
            // 
            // textBoxWN8
            // 
            this.textBoxWN8.Location = new System.Drawing.Point(324, 45);
            this.textBoxWN8.Name = "textBoxWN8";
            this.textBoxWN8.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN8.TabIndex = 7;
            // 
            // textBoxWN7
            // 
            this.textBoxWN7.Location = new System.Drawing.Point(218, 45);
            this.textBoxWN7.Name = "textBoxWN7";
            this.textBoxWN7.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN7.TabIndex = 6;
            // 
            // textBoxWN6
            // 
            this.textBoxWN6.Location = new System.Drawing.Point(112, 45);
            this.textBoxWN6.Name = "textBoxWN6";
            this.textBoxWN6.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN6.TabIndex = 5;
            // 
            // textBoxWN5
            // 
            this.textBoxWN5.Location = new System.Drawing.Point(6, 45);
            this.textBoxWN5.Name = "textBoxWN5";
            this.textBoxWN5.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN5.TabIndex = 4;
            // 
            // textBoxWN4
            // 
            this.textBoxWN4.Location = new System.Drawing.Point(324, 19);
            this.textBoxWN4.Name = "textBoxWN4";
            this.textBoxWN4.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN4.TabIndex = 3;
            // 
            // textBoxWN3
            // 
            this.textBoxWN3.Location = new System.Drawing.Point(218, 19);
            this.textBoxWN3.Name = "textBoxWN3";
            this.textBoxWN3.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN3.TabIndex = 2;
            // 
            // textBoxWN2
            // 
            this.textBoxWN2.Location = new System.Drawing.Point(112, 19);
            this.textBoxWN2.Name = "textBoxWN2";
            this.textBoxWN2.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN2.TabIndex = 1;
            // 
            // textBoxWN1
            // 
            this.textBoxWN1.Location = new System.Drawing.Point(6, 19);
            this.textBoxWN1.Name = "textBoxWN1";
            this.textBoxWN1.Size = new System.Drawing.Size(100, 20);
            this.textBoxWN1.TabIndex = 0;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(375, 144);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 0;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // Form3_wn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 174);
            this.Controls.Add(this.buttonUpdateText);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form3_wn";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form3_wn_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxWN13;
        private System.Windows.Forms.TextBox textBoxWN12;
        private System.Windows.Forms.TextBox textBoxWN11;
        private System.Windows.Forms.TextBox textBoxWN10;
        private System.Windows.Forms.TextBox textBoxWN9;
        private System.Windows.Forms.TextBox textBoxWN8;
        private System.Windows.Forms.TextBox textBoxWN7;
        private System.Windows.Forms.TextBox textBoxWN6;
        private System.Windows.Forms.TextBox textBoxWN5;
        private System.Windows.Forms.TextBox textBoxWN4;
        private System.Windows.Forms.TextBox textBoxWN3;
        private System.Windows.Forms.TextBox textBoxWN2;
        private System.Windows.Forms.TextBox textBoxWN1;
        private System.Windows.Forms.Button buttonUpdateText;
    }
}