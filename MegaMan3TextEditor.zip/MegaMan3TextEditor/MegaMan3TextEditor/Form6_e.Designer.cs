﻿namespace MegaMan3TextEditor {
    partial class Form6_e {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6_e));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxE11 = new System.Windows.Forms.TextBox();
            this.textBoxE10 = new System.Windows.Forms.TextBox();
            this.textBoxE9 = new System.Windows.Forms.TextBox();
            this.textBoxE8 = new System.Windows.Forms.TextBox();
            this.textBoxE7 = new System.Windows.Forms.TextBox();
            this.textBoxE6 = new System.Windows.Forms.TextBox();
            this.textBoxE5 = new System.Windows.Forms.TextBox();
            this.textBoxE4 = new System.Windows.Forms.TextBox();
            this.textBoxE3 = new System.Windows.Forms.TextBox();
            this.textBoxE2 = new System.Windows.Forms.TextBox();
            this.textBoxE1 = new System.Windows.Forms.TextBox();
            this.buttonUpdateText = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxE11);
            this.groupBox1.Controls.Add(this.textBoxE10);
            this.groupBox1.Controls.Add(this.textBoxE9);
            this.groupBox1.Controls.Add(this.textBoxE8);
            this.groupBox1.Controls.Add(this.textBoxE7);
            this.groupBox1.Controls.Add(this.textBoxE6);
            this.groupBox1.Controls.Add(this.textBoxE5);
            this.groupBox1.Controls.Add(this.textBoxE4);
            this.groupBox1.Controls.Add(this.textBoxE3);
            this.groupBox1.Controls.Add(this.textBoxE2);
            this.groupBox1.Controls.Add(this.textBoxE1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(438, 312);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ending";
            // 
            // textBoxE11
            // 
            this.textBoxE11.Location = new System.Drawing.Point(6, 279);
            this.textBoxE11.Name = "textBoxE11";
            this.textBoxE11.Size = new System.Drawing.Size(426, 20);
            this.textBoxE11.TabIndex = 10;
            // 
            // textBoxE10
            // 
            this.textBoxE10.Location = new System.Drawing.Point(6, 253);
            this.textBoxE10.Name = "textBoxE10";
            this.textBoxE10.Size = new System.Drawing.Size(426, 20);
            this.textBoxE10.TabIndex = 9;
            // 
            // textBoxE9
            // 
            this.textBoxE9.Location = new System.Drawing.Point(6, 227);
            this.textBoxE9.Name = "textBoxE9";
            this.textBoxE9.Size = new System.Drawing.Size(426, 20);
            this.textBoxE9.TabIndex = 8;
            // 
            // textBoxE8
            // 
            this.textBoxE8.Location = new System.Drawing.Point(6, 201);
            this.textBoxE8.Name = "textBoxE8";
            this.textBoxE8.Size = new System.Drawing.Size(426, 20);
            this.textBoxE8.TabIndex = 7;
            // 
            // textBoxE7
            // 
            this.textBoxE7.Location = new System.Drawing.Point(6, 175);
            this.textBoxE7.Name = "textBoxE7";
            this.textBoxE7.Size = new System.Drawing.Size(426, 20);
            this.textBoxE7.TabIndex = 6;
            // 
            // textBoxE6
            // 
            this.textBoxE6.Location = new System.Drawing.Point(6, 149);
            this.textBoxE6.Name = "textBoxE6";
            this.textBoxE6.Size = new System.Drawing.Size(426, 20);
            this.textBoxE6.TabIndex = 5;
            // 
            // textBoxE5
            // 
            this.textBoxE5.Location = new System.Drawing.Point(6, 123);
            this.textBoxE5.Name = "textBoxE5";
            this.textBoxE5.Size = new System.Drawing.Size(426, 20);
            this.textBoxE5.TabIndex = 4;
            // 
            // textBoxE4
            // 
            this.textBoxE4.Location = new System.Drawing.Point(6, 97);
            this.textBoxE4.Name = "textBoxE4";
            this.textBoxE4.Size = new System.Drawing.Size(426, 20);
            this.textBoxE4.TabIndex = 3;
            // 
            // textBoxE3
            // 
            this.textBoxE3.Location = new System.Drawing.Point(6, 71);
            this.textBoxE3.Name = "textBoxE3";
            this.textBoxE3.Size = new System.Drawing.Size(426, 20);
            this.textBoxE3.TabIndex = 2;
            // 
            // textBoxE2
            // 
            this.textBoxE2.Location = new System.Drawing.Point(6, 45);
            this.textBoxE2.Name = "textBoxE2";
            this.textBoxE2.Size = new System.Drawing.Size(426, 20);
            this.textBoxE2.TabIndex = 1;
            // 
            // textBoxE1
            // 
            this.textBoxE1.Location = new System.Drawing.Point(6, 19);
            this.textBoxE1.Name = "textBoxE1";
            this.textBoxE1.Size = new System.Drawing.Size(426, 20);
            this.textBoxE1.TabIndex = 0;
            // 
            // buttonUpdateText
            // 
            this.buttonUpdateText.Location = new System.Drawing.Point(375, 330);
            this.buttonUpdateText.Name = "buttonUpdateText";
            this.buttonUpdateText.Size = new System.Drawing.Size(75, 23);
            this.buttonUpdateText.TabIndex = 1;
            this.buttonUpdateText.Text = "&Update Text";
            this.buttonUpdateText.UseVisualStyleBackColor = true;
            this.buttonUpdateText.Click += new System.EventHandler(this.buttonUpdateText_Click);
            // 
            // Form6_e
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 359);
            this.Controls.Add(this.buttonUpdateText);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form6_e";
            this.Text = "MegaMan III Text Editor";
            this.Load += new System.EventHandler(this.Form6_e_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBoxE11;
        private System.Windows.Forms.TextBox textBoxE10;
        private System.Windows.Forms.TextBox textBoxE9;
        private System.Windows.Forms.TextBox textBoxE8;
        private System.Windows.Forms.TextBox textBoxE7;
        private System.Windows.Forms.TextBox textBoxE6;
        private System.Windows.Forms.TextBox textBoxE5;
        private System.Windows.Forms.TextBox textBoxE4;
        private System.Windows.Forms.TextBox textBoxE3;
        private System.Windows.Forms.TextBox textBoxE2;
        private System.Windows.Forms.TextBox textBoxE1;
        private System.Windows.Forms.Button buttonUpdateText;
    }
}